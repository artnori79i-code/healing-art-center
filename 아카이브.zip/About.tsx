// Path: components/About.tsx
import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

const PROF_URL = "https://arttherapy.sdu.ac.kr/arttherapy/cms/FR_VPRO_CON/ProfDetail.do?MENU_ID=40&SITE_NO=46&CONTENTS_NO=&ClassCode=F6003&YEAR=2026&TeacNo=231026";

const TimelineItem: React.FC<{ year: string; label: string; index: number }> = ({ year, label, index }) => {
  return (
    <div className="flex flex-col items-center text-center group relative min-w-[80px] md:min-w-[100px]">
      <span className="text-[12px] md:text-[14px] font-black mb-2 block font-gothic tracking-tight text-neutral-800">
        {label}
      </span>
      <div className={`w-2 h-2 md:w-3 md:h-3 rounded-full border border-white shadow-sm ${index < 6 ? 'bg-blue-800' : 'bg-blue-600'}`} />
      <span className="text-[8px] font-bold text-neutral-400 mt-1.5 font-gothic tracking-widest">{year}</span>
    </div>
  );
};

const About: React.FC = () => {
  const { scrollYProgress } = useScroll();
  const profileRotate = useTransform(scrollYProgress, [0.1, 0.4], [-2, 2]);
  const profileY = useTransform(scrollYProgress, [0.1, 0.4], [0, -30]);
  const imageScale = useTransform(scrollYProgress, [0.1, 0.3], [1.1, 1]);

  const timelineData = [
    { year: "2011", label: "초기" }, { year: "2013", label: "도약" },
    { year: "2015", label: "전국" }, { year: "2018", label: "심화" },
    { year: "2019", label: "성장" }, { year: "2020", label: "AI도입" },
    { year: "2023", label: "확장" }, { year: "2025", label: "융합" }
  ];

  return (
    <div className="bg-white py-16 md:py-24 overflow-hidden border-t border-neutral-50">
      <div className="container mx-auto px-6 max-w-6xl">
        <div className="flex flex-col md:flex-row justify-between items-start mb-16 gap-6">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-left"
          >
            <div className="flex items-center justify-start gap-3 mb-3">
              <div className="w-8 h-8 rounded-full overflow-hidden border border-blue-100">
                <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200&h=200&auto=format&fit=crop" alt="Director" className="w-full h-full object-cover" />
              </div>
              <div className="h-[1px] w-6 bg-blue-600/20" />
            </div>
            <h2 className="text-xl md:text-3xl font-black tracking-tighter uppercase font-gothic text-neutral-900">
              HEALING 예술터
            </h2>
          </motion.div>
          <div className="hidden md:flex gap-4 text-[8px] font-black tracking-[0.2em] uppercase text-neutral-300 font-gothic">
            <span className="text-neutral-900">Director</span>
            <span>Portfolio</span>
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95, filter: "blur(10px)" }}
          whileInView={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
          transition={{ duration: 1.2, ease: "easeOut" }}
          viewport={{ once: true, margin: "-100px" }}
          className="relative mb-24 max-w-4xl mx-auto"
        >
          <div className="grid md:grid-cols-2 gap-8 items-center text-left">
            <div className="relative overflow-hidden rounded-[1.5rem] md:rounded-[2.5rem] shadow-2xl border border-white">
              {/* Added persistent breathing and subtle movement animation to this image */}
              <motion.img 
                style={{ scale: imageScale }}
                animate={{ 
                  scale: [1, 1.04, 1],
                  rotate: [0, 0.5, -0.5, 0],
                  filter: ["brightness(1)", "brightness(1.05)", "brightness(1)"]
                }}
                transition={{ 
                  duration: 8, 
                  repeat: Infinity, 
                  ease: "easeInOut" 
                }}
                src="https://images.unsplash.com/photo-1511379938547-c1f69419868d?q=80&w=1200&h=800&auto=format&fit=crop" 
                alt="Activity" 
                className="w-full h-full object-cover" 
              />
            </div>
            <div className="space-y-4 px-2">
              <h3 className="text-lg md:text-2xl font-gothic font-black text-neutral-900 tracking-tight">힐링예술터 소개</h3>
              <p className="text-neutral-400 text-[13px] md:text-sm leading-relaxed font-gothic max-w-xs md:max-w-none">
                2011년부터 전국 공공기관과 예술교육 현장에서 긍정적인 변화를 만들어가고 있습니다.
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="mb-24 overflow-x-auto pb-4 scrollbar-hide">
          <div className="min-w-[700px] md:min-w-[900px] relative px-4 mx-auto">
            <div className="absolute top-[40px] md:top-[48px] left-0 w-full h-[1px] bg-neutral-100" />
            <div className="flex justify-between relative z-10">
              {timelineData.map((item, i) => (
                <TimelineItem key={i} index={i} {...item} />
              ))}
            </div>
          </div>
        </motion.div>

        <div className="flex justify-center w-full mb-16">
          <motion.div 
            initial={{ opacity: 0, y: 50 }} 
            whileInView={{ opacity: 1, y: 0 }} 
            transition={{ duration: 0.8 }}
            viewport={{ once: true }} 
            className="max-w-5xl w-full"
          >
            <div className="grid md:grid-cols-[1fr_1.5fr] gap-10 md:gap-20 items-center">
              <div className="flex flex-col items-center">
                <motion.div 
                  style={{ rotate: profileRotate, y: profileY }} 
                  className="w-[260px] md:w-full aspect-[3/4] rounded-[2rem] overflow-hidden shadow-2xl border-white border-4 md:border-8 mb-6 group"
                >
                  <motion.img 
                    initial={{ scale: 1.2 }}
                    whileInView={{ scale: 1 }}
                    transition={{ duration: 1.5 }}
                    src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=90&w=1200&h=1600&auto=format&fit=crop" 
                    alt="Director Profile" 
                    className="w-full h-full object-cover transition-transform duration-[3000ms] group-hover:scale-110" 
                  />
                </motion.div>
                
                <div className="text-center">
                  <h4 className="text-2xl md:text-3xl font-black text-neutral-900 font-gothic tracking-tighter mb-1">이성경</h4>
                  <p className="text-blue-600 font-black text-[9px] md:text-[10px] tracking-[0.3em] uppercase font-gothic">Art Director</p>
                </div>
              </div>

              <div className="text-left space-y-10">
                <div className="border-b border-neutral-100 pb-8">
                  <h5 className="text-[9px] font-black text-neutral-300 uppercase tracking-[0.4em] mb-6 font-gothic">Director Insight</h5>
                  <p className="text-xl md:text-[32px] font-black text-neutral-800 leading-[1.4] font-gothic tracking-tight">
                    "예술이 머무는 일상에서 더 넓고 <br className="block md:hidden" />
                    풍요로운 삶의 풍경을 마주합니다."
                  </p>
                </div>
                
                <div className="space-y-4">
                  <h6 className="text-[12px] font-black text-neutral-900 flex items-center justify-start gap-3 font-gothic uppercase tracking-widest">
                    <span className="w-4 h-[2px] bg-blue-600"></span> 주요 약력
                  </h6>
                  <ul className="text-[13px] md:text-[14px] text-neutral-500 space-y-2.5 font-medium font-gothic leading-tight text-left">
                      <li>• 이화여자대학교 교육대학원 음악치료 졸업</li>
                      <li>• 이화여자대학교 문화예술교육원 무용학/음악학 수료</li>
                      <li>• 연세대학교 신학과 졸업</li>
                      <li className="font-bold text-neutral-800">• 現) 국방부 문화예술교육 총괄 기획자</li>
                      <li className="font-bold text-neutral-800">• 現) 서울디지털대학교 음악치료 교수</li>
                      <li>• 前) 이화여대 예술교육치료연구소 연구원</li>
                  </ul>
                </div>

                <div className="pt-4 flex justify-start">
                  <motion.a 
                    href={PROF_URL} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="inline-flex items-center gap-4 bg-white border border-neutral-100 px-8 py-4 rounded-full shadow-sm hover:shadow-md transition-all group"
                  >
                    <span className="text-[10px] font-black tracking-[0.2em] uppercase text-neutral-800 font-gothic">Profile Archive</span>
                    <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center text-white">
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                      </svg>
                    </div>
                  </motion.a>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default About;