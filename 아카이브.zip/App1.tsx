import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Programs from './components/Programs';
import Reviews from './components/Reviews';
import Insight from './components/Insight';
import Footer from './components/Footer';
import ApplyModal from './components/ApplyModal';
import AIConsultant from './components/AIConsultant';

const App: React.FC = () => {
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);

  return (
    <div className="relative">
      <Header onApplyClick={() => setIsApplyModalOpen(true)} />
      <main>
        <section id="home">
          <Hero />
        </section>
        <section id="about">
          <About />
        </section>
        <section id="program">
          <Programs />
        </section>
        <section id="review">
          <Reviews />
        </section>
        <section id="insight">
          <Insight />
        </section>
      </main>
      <Footer />
      <ApplyModal 
        isOpen={isApplyModalOpen} 
        onClose={() => setIsApplyModalOpen(false)} 
      />
      <AIConsultant />
    </div>
  );
};

export default App;