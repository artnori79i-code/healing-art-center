// Path: components/AIConsultant.tsx
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { GoogleGenAI } from "@google/genai";

const AIConsultant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{role: 'user' | 'ai', text: string}[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    
    const userMessage = input.trim();
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setInput('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `당신은 '힐링예술터'의 전문 예술 교육 컨설턴트입니다. 
        사용자의 상황(예: 군장병, 기업인, 시니어, 산모, 환자 등)에 맞춰 
        힐링예술터의 프로그램 중 가장 적합한 것을 추천하고, 예술적이고 공감 넘치는 문체로 설명해주세요.
        사용자의 문의: ${userMessage}`,
      });

      const aiText = response.text || "죄송합니다. 상담 내용을 정리 중 오류가 발생했습니다.";
      setMessages(prev => [...prev, { role: 'ai', text: aiText }]);
    } catch (error: any) {
      console.error("AI Consultant Error:", error);
      let errorMessage = "네트워크 오류가 발생했습니다.";
      if (error.message?.includes("Requested entity was not found")) {
        if (typeof window !== 'undefined' && (window as any).aistudio?.openSelectKey) {
          (window as any).aistudio.openSelectKey();
        }
        errorMessage = "상담을 위해 API 키 설정이 필요합니다.";
      }
      setMessages(prev => [...prev, { role: 'ai', text: errorMessage }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <div className="fixed bottom-6 right-6 z-[60]">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsOpen(!isOpen)}
          className="w-14 h-14 bg-blue-600 text-white rounded-full shadow-2xl flex items-center justify-center relative overflow-hidden group"
        >
          <div className="absolute inset-0 bg-white/20 scale-0 group-hover:scale-100 transition-transform rounded-full" />
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
        </motion.button>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-24 right-6 w-80 md:w-96 h-[500px] bg-white rounded-3xl shadow-2xl z-[60] flex flex-col border border-neutral-100 overflow-hidden"
          >
            <div className="p-5 bg-blue-600 text-white flex justify-between items-center">
              <div>
                <h4 className="font-gothic font-black text-sm tracking-tighter">AI 힐링 컨설턴트</h4>
                <p className="text-[10px] opacity-70">실시간 맞춤형 프로그램 상담</p>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-white/60 hover:text-white"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
            </div>
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              <div className="bg-blue-50 p-3 rounded-2xl text-[12px] text-blue-800 font-medium">
                안녕하세요! 궁금하신 점을 말씀해 주시면 최적의 솔루션을 제안해 드립니다.
              </div>
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-3 rounded-2xl text-[13px] ${msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-neutral-100 text-neutral-800'}`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isLoading && <div className="text-[10px] text-neutral-400">AI가 답변을 생성 중입니다...</div>}
            </div>
            <div className="p-4 border-t bg-neutral-50/50">
              <div className="flex gap-2">
                <input type="text" value={input} onChange={(e) => setInput(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && handleSend()} placeholder="상담 내용을 입력하세요..." className="flex-1 bg-white border rounded-xl px-4 py-2 text-sm focus:outline-none" />
                <button onClick={handleSend} disabled={isLoading || !input.trim()} className="bg-blue-600 text-white p-2.5 rounded-xl">전송</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default AIConsultant;